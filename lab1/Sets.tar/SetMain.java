/******************************************************************************
 * Compilation:  javac SetMain.java
 * Execution:    java SetMain
 * Dependencies: Set.java, SetImpl.java
 *
 * Version 0.1,  2017
 * @author Michael Hay
 */

/**
 * A simple program to demonstrate the functionality of sets.
 */
public class SetMain {

    /**
     * Demonstrates that the set implementation works correctly.
     * @param args should be empty
     */
    public static void main(String[] args) {

        System.out.println("Initialize S = { a, b, c }");
        Set<String> S = new SetImpl<>(new String[] {"a", "b", "c", "a"});
        System.out.println("|S| = " + S.cardinality());
        System.out.println("a in S = " + S.in("a"));

        System.out.println("Initialize T = { c, d }");
        Set<String> T = new SetImpl<>(new String[] {"c", "d"});

        System.out.println("|S union T| = " + S.union(T).cardinality());

         // you are expected to add more code here
         // this main program should provide clear and convincing evidence that your set implementation
         // works correctly.
         // the code here will count for a significant part of your grade on this lab
    }

}
